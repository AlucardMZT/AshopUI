import { Component } from '@angular/core';
import {AuthService} from '../../services/auth.service';
import {Router, RouterLink} from '@angular/router';
import {CommonModule, NgIf} from '@angular/common';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {MatFormField, MatInput, MatInputModule, MatLabel} from '@angular/material/input';
import {MatCard} from '@angular/material/card';
import {MatButton, MatButtonModule} from '@angular/material/button';
import {UserRegisterRequest} from '../../models/register.model';
import {MatFormFieldModule} from '@angular/material/form-field';

@Component({
  selector: 'app-register',
  imports: [CommonModule, FormsModule, ReactiveFormsModule, MatInputModule, MatFormFieldModule, MatButtonModule, RouterLink],
  standalone: true,
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent {
  name = '';
  email = '';
  password = '';
  nickname = '';
  address = '';
  postalCode = '';
  phone = '';
  state = '';
  municipality = '';
  houseDescription = '';

  errorMessage = '';
  successMessage = '';

  constructor(private authService: AuthService, private router: Router) {}

  onRegister(): void {
    if (!this.name || !this.email || !this.password || !this.address || !this.postalCode || !this.phone) {
      this.errorMessage = 'Todos los campos son obligatorios.';
      return;
    }

    const user: UserRegisterRequest = {
      name: this.name,
      email: this.email,
      password: this.password,
      nickname: this.nickname,
      address: this.address,
      postalCode: this.postalCode,
      phone: this.phone,
      state: this.state,
      municipality: this.municipality,
      houseDescription: this.houseDescription
    };

    this.authService.register(user).subscribe({
      next: () => {
        this.successMessage = '¡Registro exitoso! Redireccionando...';
        setTimeout(() => this.router.navigate(['/login']), 2000);
      },
      error: () => {
        this.errorMessage = 'Error al registrar. Intenta con otro correo.';
      }
    });
  }
}
