import { Component } from '@angular/core';
import {FooterComponent} from '../footer/footer.component';
import {Router, RouterLink, RouterLinkActive, RouterOutlet} from '@angular/router';
import {MatAnchor, MatButton} from '@angular/material/button';
import {MatToolbar} from '@angular/material/toolbar';
import {AuthService} from '../../services/auth.service';

@Component({
  selector: 'app-layout',
  imports: [
    MatAnchor,
    RouterLink,
    MatToolbar,
    RouterLinkActive,
    MatButton
  ],
  templateUrl: './layout.component.html',
  styleUrl: './layout.component.scss'
})
export class LayoutComponent {
  nickname: string | null = null;

  constructor(private authService: AuthService, private router: Router) {}

  ngOnInit() {
    this.nickname = this.authService.getNickname();
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/']);
    this.nickname = null;
  }
}
